package p1;

public class JoinTest {
public static void main(String[] args) throws InterruptedException{
	MyRunnable mr = new MyRunnable();
	Thread t1 = new Thread(mr);
	t1.start();
	t1.join();
	t1.start();
}
}

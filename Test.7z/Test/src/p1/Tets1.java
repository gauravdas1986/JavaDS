package p1;

import java.util.ArrayList;
import java.util.List;

public class Tets1 {
	public static void main(String[] args) {
		List l = new ArrayList();

		l.add("a");
		l.add("b");
		l.add("c");
		l.add("d");
		
		for(int i=0;i<4;i++) {
			
//			l.remove(0);
			System.out.println(l.get(i));
		}
		
		System.out.println((Integer)500==(Integer)500);
		
	}
}

package p1;

import java.util.HashMap;

public class DuplicateKey {
public static void main(String[] args) {
	HashMap hs = new HashMap();
	BadKey bk1 = new BadKey("AAA");
	BadKey bk2 = new BadKey("AAA");
	BadKey bk3 = new BadKey("AAA");
	BadKey bk4 = new BadKey("AAA");
	hs.put(bk1, 1);
	hs.put(bk2, 2);
	hs.put(bk3, 3);
	hs.put(bk4, 4);
	System.out.println(hs.get(bk2));
	
	String s1 = "AA";
	String s2 = "BB";
	String s3 = "CC";
	HashMap hm1 = new HashMap();
	hm1.put(s1, "1");
	hm1.put(s2, "2");
	hm1.put(s3, "3");
	s1 = s1+"BB";

	System.out.println(hm1.get("AA"));
	System.out.println(hm1.get(s1));
	
	
	StringBuffer sb1 = new StringBuffer();
	sb1.append("XX");
	StringBuffer sb2 = new StringBuffer();
	sb2.append("YY");
	StringBuffer sb3 = new StringBuffer();
	sb3.append("ZZ");
	hm1.put(sb1, "5");
	hm1.put(sb2, "6");
	hm1.put(sb3, "7");
	
	sb1.append("Z");
	System.out.println(hm1.get(sb1));
	
}
}
class BadKey{
	String key;
	public BadKey(String key) {
		this.key = key;
	}
}

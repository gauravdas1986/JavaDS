package p1;

public class SpiralMatrix {
	public static void main(String[] args) {
		int[][] arr = { { 5, 8, 7, 6, 3 }, { 1, 2, 3, 9, 6 },
				{ 9, 6, 88, 2, 5 }, { 5, 6, 7, 9, 3 }, { 1, 9, 3, 7, 6 } };
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {

				System.out.print(arr[i][j] + " ");

			}
			System.out.println();
		}
		System.out.println("________________");
		int upperRow = 5;
		int rightCol = 5;
		int bottomRow = 5;
		int leftCol = 5;
		for(int t=0;t<5;t++){
		for (int i = 0; i < upperRow-t; i++) {
//			System.out.println(5 - upperRow+"_"+i);
			System.out.print(arr[5 - upperRow][i+t]);
		}
		upperRow--;
		for(int i=0;i<rightCol-1-t;i++){
//			System.out.println((i+1)+"_"+(rightCol-1));
			System.out.print(arr[i+1+t][rightCol-1]);
		}
		rightCol--;
		for(int i=1;i<bottomRow-t;i++){
//			System.out.println((bottomRow-1)+"_"+(upperRow-i));
			System.out.print(arr[bottomRow-1][upperRow-i]);
		}
		bottomRow--;
		for(int i=1;i<leftCol-1-t;i++){
//			System.out.println((bottomRow-i)+"_"+(5-leftCol));
			System.out.print(arr[bottomRow-i][5-leftCol]);
		}
		leftCol--;
		System.out.println("_");
		}
	}
}

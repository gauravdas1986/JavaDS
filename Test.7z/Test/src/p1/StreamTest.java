package p1;

public class StreamTest {

}

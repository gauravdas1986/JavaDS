package p1;

import java.io.IOException;

public class OverloadTest {
	public static void main(String[] args) {
		new OverloadTest().display(null);
	}
	
	public void display(Object obj) {
		System.out.println("Object");
	}
	public void display(String obj) {
		System.out.println("String");
	}
	public void display(StringBuffer obj) {
		System.out.println("StringBuffer");
	}
	
	/*public void display(Exception str) {
		System.out.println("Exception");
	}
	public void display(IOException in) {
		System.out.println("IO exception");
	}*/
}

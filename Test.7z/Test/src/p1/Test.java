package p1;

import java.util.HashMap;
import java.util.Map;

public class Test {

	Map hm = new HashMap();
	public static void main(String[] args) {
		 int[] arr  = {8,5,2,17,4,6,19,1,2};
		 new Test().helper(arr, -1);
//		 System.out.println(this.hm);
	}
	public int helper(int[] arr,int step){
		if(hm.containsKey(step)){
			return ((Integer) hm.get(step)).intValue();
		}
		if(step >= arr.length-2){
			return 0;
		}
		int result = Math.min(arr[step+1]+helper(arr,step+1), arr[step+2]+helper(arr,step+2));
		hm.put(step, result);
		System.out.println(result+" ");
		return result;
	}
}

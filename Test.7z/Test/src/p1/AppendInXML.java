package p1;

public class AppendInXML {
	public static void main(String[] args) {
		String xmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> " +
				"<ROOT><ANNUAL_SURVEY_DATE_5>02 February 2018</ANNUAL_SURVEY_DATE_5>" +
				"<ANNUAL_SURVEY_PLACE_5>locnn</ANNUAL_SURVEY_PLACE_5>" +
				"<ANNUAL_SURVEY_RPT_NUM_5>HS3443567</ANNUAL_SURVEY_RPT_NUM_5>" +
				"<ANNUAL_SURVEY_SURVEYOR_5>Electronically Signed By \nThambyrajah, Roger, Corporate IMS Application Services</ANNUAL_SURVEY_SURVEYOR_5>" +
				"</ROOT>";
		String endXml = "<STRIKE_ANNUAL_5></STRIKE_ANNUAL_5>" +
				"<STRIKE_INTERM_PERIOD_5>visible</STRIKE_INTERM_PERIOD_5>" +
				"<PROP_DIAMETER_UOM>10</PROP_DIAMETER_UOM>";
		System.out.println(insertText(xmlStr,"</ROOT>",endXml));
	}

	public static String insertText(String source, String insertAfter,
			String insertVal) {
		StringBuffer sb = null;
		if (source != null) {
			sb = new StringBuffer(source);
			int index = sb.indexOf(insertAfter);
			if (index >= 0) {
				sb.insert(index , insertVal);
			}
			return sb.toString();
		} else {
			return "";
		}

	}
}

package ds;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class LinkedListRecursion {

	public static void main(String[] args) {
		LinkedList ll = new LinkedList();
		ll.add("A");
		ll.add("B");
		ll.add("C");
		ll.add(null);
		
		/*Iterator itr =  ll.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}*/
		
		reverse(ll,0);
		
	}
	
	public static void reverse(List ll,int count) {
		String str = (String) ll.get(count);
		if(ll.get(count) != null) {
			reverse(ll,++count);
			System.out.println(str);
		}
	}
}
